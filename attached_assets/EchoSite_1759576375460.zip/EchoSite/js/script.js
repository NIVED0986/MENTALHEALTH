function initializeDemoData() {
    if (!localStorage.getItem('echoDemoInitialized')) {
        localStorage.setItem('echoPoints', '245');
        localStorage.setItem('echoLevel', '3');
        localStorage.setItem('echoStreak', '12');
        localStorage.setItem('echoLastActivity', new Date().toDateString());
        
        localStorage.setItem('echoActivities', JSON.stringify({
            moods: 18,
            habits: 24,
            todos: 15,
            journals: 8,
            exercises: 6
        }));
        
        localStorage.setItem('echoBadges', JSON.stringify([
            { id: 'first_mood', name: 'Mood Tracker', emoji: '😊' },
            { id: 'mood_master', name: 'Mood Master', emoji: '🌟' },
            { id: 'habit_starter', name: 'Habit Starter', emoji: '✓' },
            { id: 'consistent', name: 'Consistent', emoji: '🔥' },
            { id: 'calm_master', name: 'Calm Master', emoji: '🧘' },
            { id: 'journal_pro', name: 'Journal Pro', emoji: '📝' },
            { id: 'week_streak', name: '7-Day Streak', emoji: '🌈' }
        ]));
        
        localStorage.setItem('moodData', JSON.stringify({
            happy: 6,
            sad: 2,
            anxious: 3,
            calm: 4,
            energetic: 3
        }));
        
        localStorage.setItem('habits', JSON.stringify([
            'Morning Meditation',
            'Drink Water',
            'Exercise 30min',
            'Journaling'
        ]));
        
        localStorage.setItem('habitChecks', JSON.stringify({
            '0-0': true, '0-1': true, '0-3': true, '0-5': true, '0-6': true, '0-8': true,
            '1-0': true, '1-1': true, '1-2': true, '1-4': true, '1-6': true,
            '2-1': true, '2-2': true, '2-3': true, '2-5': true, '2-7': true,
            '3-0': true, '3-2': true, '3-4': true, '3-5': true, '3-6': true
        }));
        
        localStorage.setItem('todos', JSON.stringify([
            { text: 'Review today\'s mood patterns', completed: true },
            { text: 'Practice breathing exercises', completed: true },
            { text: 'Write gratitude journal entry', completed: false },
            { text: 'Complete evening meditation', completed: false },
            { text: 'Track water intake', completed: true }
        ]));
        
        localStorage.setItem('echoDemoInitialized', 'true');
    }
}

class EchoGamification {
    constructor() {
        this.points = parseInt(localStorage.getItem('echoPoints')) || 0;
        this.level = parseInt(localStorage.getItem('echoLevel')) || 1;
        this.lastActivityDate = localStorage.getItem('echoLastActivity') || null;
        this.streakCount = parseInt(localStorage.getItem('echoStreak')) || 0;
        this.badges = JSON.parse(localStorage.getItem('echoBadges')) || [];
        this.activities = JSON.parse(localStorage.getItem('echoActivities')) || {
            moods: 0,
            habits: 0,
            todos: 0,
            journals: 0,
            exercises: 0
        };
        this.checkStreak();
    }

    checkStreak() {
        const today = new Date().toDateString();
        if (this.lastActivityDate !== today) {
            const lastDate = this.lastActivityDate ? new Date(this.lastActivityDate) : null;
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            
            if (lastDate && lastDate.toDateString() === yesterday.toDateString()) {
                this.streakCount++;
            } else if (lastDate && lastDate.toDateString() !== today) {
                this.streakCount = 1;
            } else if (!lastDate) {
                this.streakCount = 1;
            }
            
            this.lastActivityDate = today;
            localStorage.setItem('echoLastActivity', today);
            localStorage.setItem('echoStreak', this.streakCount);
        }
    }

    addPoints(amount, activity) {
        this.points += amount;
        const oldLevel = this.level;
        this.level = Math.floor(this.points / 100) + 1;
        
        if (activity) {
            this.activities[activity] = (this.activities[activity] || 0) + 1;
            localStorage.setItem('echoActivities', JSON.stringify(this.activities));
        }
        
        localStorage.setItem('echoPoints', this.points);
        localStorage.setItem('echoLevel', this.level);
        
        this.checkBadges();
        
        if (this.level > oldLevel) {
            this.showLevelUp();
        }
    }

    checkBadges() {
        const badgeDefinitions = [
            { id: 'first_mood', name: 'Mood Tracker', condition: () => this.activities.moods >= 1, emoji: '😊' },
            { id: 'mood_master', name: 'Mood Master', condition: () => this.activities.moods >= 10, emoji: '🌟' },
            { id: 'habit_starter', name: 'Habit Starter', condition: () => this.activities.habits >= 1, emoji: '✓' },
            { id: 'consistent', name: 'Consistent', condition: () => this.streakCount >= 7, emoji: '🔥' },
            { id: 'calm_master', name: 'Calm Master', condition: () => this.activities.exercises >= 5, emoji: '🧘' },
            { id: 'journal_pro', name: 'Journal Pro', condition: () => this.activities.journals >= 5, emoji: '📝' },
            { id: 'task_warrior', name: 'Task Warrior', condition: () => this.activities.todos >= 10, emoji: '⚔️' },
            { id: 'week_streak', name: '7-Day Streak', condition: () => this.streakCount >= 7, emoji: '🌈' },
            { id: 'month_streak', name: '30-Day Streak', condition: () => this.streakCount >= 30, emoji: '💎' },
        ];

        badgeDefinitions.forEach(badge => {
            if (badge.condition() && !this.badges.find(b => b.id === badge.id)) {
                this.badges.push(badge);
                localStorage.setItem('echoBadges', JSON.stringify(this.badges));
                this.showBadgeUnlock(badge);
            }
        });
    }

    showLevelUp() {
        if (typeof showNotification === 'function') {
            showNotification(`Level Up! You're now Level ${this.level}! 🎉`);
        }
    }

    showBadgeUnlock(badge) {
        if (typeof showNotification === 'function') {
            showNotification(`Badge Unlocked: ${badge.emoji} ${badge.name}!`);
        }
    }

    getStats() {
        return {
            points: this.points,
            level: this.level,
            streak: this.streakCount,
            badges: this.badges,
            activities: this.activities,
            nextLevelPoints: (this.level * 100)
        };
    }
}

initializeDemoData();
const gamification = new EchoGamification();

function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: rgba(139, 92, 246, 0.95);
        backdrop-filter: blur(20px);
        color: white;
        padding: 1.2rem 2rem;
        border-radius: 16px;
        box-shadow: 0 10px 40px rgba(139, 92, 246, 0.5);
        z-index: 10000;
        animation: slideInRight 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: 1px solid rgba(255, 255, 255, 0.2);
        font-weight: 600;
        font-family: 'Poppins', sans-serif;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }
    
    const pageName = window.location.pathname.split('/').pop().replace('.html', '') || 'index';
    
    switch(pageName) {
        case 'index':
            initHome();
            break;
        case 'mood':
            initMoodTracker();
            break;
        case 'habit':
            initHabitTracker();
            break;
        case 'todo':
            initTodoList();
            break;
        case 'chai':
            initChaiRooms();
            break;
        case 'ai':
            initAIChat();
            break;
        case 'journal':
            initJournal();
            break;
        case 'exercise':
            initExercises();
            break;
        case 'rewards':
            initRewards();
            break;
        case 'contact':
            initContact();
            break;
    }
});

function initHome() {
    const elements = document.querySelectorAll('.card, .hero');
    elements.forEach((el, index) => {
        el.style.animationDelay = `${index * 0.1}s`;
    });
}

function initMoodTracker() {
    const canvas = document.getElementById('moodChart');
    const ctx = canvas.getContext('2d');
    const moodButtons = document.querySelectorAll('.mood-btn');
    
    let moodData = JSON.parse(localStorage.getItem('moodData')) || {
        happy: 0,
        sad: 0,
        anxious: 0,
        calm: 0,
        energetic: 0
    };
    
    function drawChart() {
        const total = Object.values(moodData).reduce((a, b) => a + b, 0);
        if (total === 0) {
            ctx.fillStyle = '#e2e8f0';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#2d3748';
            ctx.font = '20px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('Select moods to see your chart', canvas.width / 2, canvas.height / 2);
            return;
        }
        
        const colors = ['#667eea', '#f093fb', '#43e97b', '#4facfe', '#fee140'];
        const moods = Object.keys(moodData);
        let currentAngle = 0;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        moods.forEach((mood, index) => {
            const sliceAngle = (moodData[mood] / total) * Math.PI * 2;
            
            ctx.beginPath();
            ctx.arc(canvas.width / 2, canvas.height / 2, 150, currentAngle, currentAngle + sliceAngle);
            ctx.lineTo(canvas.width / 2, canvas.height / 2);
            ctx.fillStyle = colors[index];
            ctx.fill();
            
            currentAngle += sliceAngle;
        });
    }
    
    moodButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const mood = this.dataset.mood;
            moodData[mood]++;
            localStorage.setItem('moodData', JSON.stringify(moodData));
            
            moodButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            drawChart();
            gamification.addPoints(5, 'moods');
            showNotification('Mood logged! +5 points');
        });
    });
    
    drawChart();
}

function initHabitTracker() {
    const habitCalendar = document.getElementById('habitCalendar');
    const habitInput = document.getElementById('habitInput');
    const addHabitBtn = document.getElementById('addHabitBtn');
    const habitList = document.getElementById('habitList');
    
    let habits = JSON.parse(localStorage.getItem('habits')) || [];
    let habitChecks = JSON.parse(localStorage.getItem('habitChecks')) || {};
    
    function renderHabits() {
        habitList.innerHTML = '';
        habits.forEach((habit, index) => {
            const habitItem = document.createElement('div');
            habitItem.className = 'card';
            habitItem.innerHTML = `
                <h3>${habit}</h3>
                <div class="habit-calendar" id="calendar-${index}"></div>
            `;
            habitList.appendChild(habitItem);
            renderCalendar(index);
        });
    }
    
    function renderCalendar(habitIndex) {
        const calendar = document.getElementById(`calendar-${habitIndex}`);
        calendar.innerHTML = '';
        
        for (let i = 0; i < 30; i++) {
            const day = document.createElement('div');
            day.className = 'habit-day';
            const dateKey = `${habitIndex}-${i}`;
            
            if (habitChecks[dateKey]) {
                day.classList.add('checked');
                day.innerHTML = '✓';
            } else {
                day.textContent = i + 1;
            }
            
            day.addEventListener('click', () => {
                if (habitChecks[dateKey]) {
                    delete habitChecks[dateKey];
                    day.classList.remove('checked');
                    day.textContent = i + 1;
                } else {
                    habitChecks[dateKey] = true;
                    day.classList.add('checked');
                    day.innerHTML = '✓';
                    gamification.addPoints(3, 'habits');
                    showNotification('Habit completed! +3 points');
                }
                localStorage.setItem('habitChecks', JSON.stringify(habitChecks));
            });
            
            calendar.appendChild(day);
        }
    }
    
    addHabitBtn.addEventListener('click', () => {
        const habitName = habitInput.value.trim();
        if (habitName) {
            habits.push(habitName);
            localStorage.setItem('habits', JSON.stringify(habits));
            habitInput.value = '';
            renderHabits();
        }
    });
    
    renderHabits();
}

function initTodoList() {
    const todoInput = document.getElementById('todoInput');
    const addTodoBtn = document.getElementById('addTodoBtn');
    const todoList = document.getElementById('todoList');
    
    let todos = JSON.parse(localStorage.getItem('todos')) || [];
    
    function renderTodos() {
        todoList.innerHTML = '';
        todos.forEach((todo, index) => {
            const todoItem = document.createElement('div');
            todoItem.className = `todo-item ${todo.completed ? 'completed' : ''}`;
            todoItem.innerHTML = `
                <input type="checkbox" ${todo.completed ? 'checked' : ''} onchange="toggleTodo(${index})">
                <span ondblclick="editTodo(${index})">${todo.text}</span>
                <button onclick="deleteTodo(${index})" style="margin-left: auto;">Delete</button>
            `;
            todoList.appendChild(todoItem);
        });
    }
    
    window.toggleTodo = function(index) {
        todos[index].completed = !todos[index].completed;
        if (todos[index].completed) {
            gamification.addPoints(2, 'todos');
            showNotification('Task completed! +2 points');
        }
        localStorage.setItem('todos', JSON.stringify(todos));
        renderTodos();
    };
    
    window.editTodo = function(index) {
        const newText = prompt('Edit task:', todos[index].text);
        if (newText !== null && newText.trim()) {
            todos[index].text = newText.trim();
            localStorage.setItem('todos', JSON.stringify(todos));
            renderTodos();
        }
    };
    
    window.deleteTodo = function(index) {
        todos.splice(index, 1);
        localStorage.setItem('todos', JSON.stringify(todos));
        renderTodos();
    };
    
    addTodoBtn.addEventListener('click', () => {
        const text = todoInput.value.trim();
        if (text) {
            todos.push({ text, completed: false });
            localStorage.setItem('todos', JSON.stringify(todos));
            todoInput.value = '';
            renderTodos();
        }
    });
    
    todoInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addTodoBtn.click();
        }
    });
    
    renderTodos();
}

function initChaiRooms() {
    const languageSelect = document.getElementById('languageSelect');
    const chatMessages = document.getElementById('chatMessages');
    const messageInput = document.getElementById('messageInput');
    const sendBtn = document.getElementById('sendBtn');
    
    const responses = {
        english: ['Hello! How can I help you today?', 'That sounds interesting!', 'Tell me more about that.', 'I understand how you feel.'],
        hindi: ['नमस्ते! मैं आपकी कैसे मदद कर सकता हूं?', 'यह दिलचस्प लगता है!', 'मुझे इसके बारे में और बताएं।', 'मैं समझता हूं कि आप कैसा महसूस करते हैं।'],
        spanish: ['¡Hola! ¿Cómo puedo ayudarte hoy?', '¡Eso suena interesante!', 'Cuéntame más sobre eso.', 'Entiendo cómo te sientes.'],
        french: ['Bonjour! Comment puis-je vous aider aujourd\'hui?', 'Cela semble intéressant!', 'Parlez-moi en plus.', 'Je comprends ce que vous ressentez.']
    };
    
    function addMessage(text, isUser) {
        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${isUser ? 'user' : 'bot'}`;
        bubble.textContent = text;
        chatMessages.appendChild(bubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    sendBtn.addEventListener('click', () => {
        const message = messageInput.value.trim();
        if (message) {
            addMessage(message, true);
            messageInput.value = '';
            
            setTimeout(() => {
                const lang = languageSelect.value;
                const responseList = responses[lang];
                const response = responseList[Math.floor(Math.random() * responseList.length)];
                addMessage(response, false);
            }, 1000);
        }
    });
    
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendBtn.click();
        }
    });
}

function initAIChat() {
    const toneSelect = document.getElementById('toneSelect');
    const chatMessages = document.getElementById('aiChatMessages');
    const messageInput = document.getElementById('aiMessageInput');
    const sendBtn = document.getElementById('aiSendBtn');
    
    const toneResponses = {
        friendly: ['Hey there! 😊 I\'m here to chat!', 'That\'s awesome! Tell me more!', 'I love your energy!', 'You\'re doing great!'],
        calm: ['Take a deep breath... I\'m here to listen.', 'Everything will be okay.', 'Let\'s work through this together.', 'You\'re safe here.'],
        motivating: ['You\'ve got this! 💪', 'Every step forward is progress!', 'Believe in yourself!', 'You\'re stronger than you think!'],
        professional: ['I understand your concern.', 'Let\'s analyze this situation.', 'Here\'s what I recommend.', 'That\'s a valid point.']
    };
    
    function addMessage(text, isUser) {
        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${isUser ? 'user' : 'bot'}`;
        bubble.textContent = text;
        chatMessages.appendChild(bubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    sendBtn.addEventListener('click', () => {
        const message = messageInput.value.trim();
        if (message) {
            addMessage(message, true);
            messageInput.value = '';
            
            setTimeout(() => {
                const tone = toneSelect.value;
                const responseList = toneResponses[tone];
                const response = responseList[Math.floor(Math.random() * responseList.length)];
                addMessage(response, false);
            }, 1000);
        }
    });
    
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendBtn.click();
        }
    });
}

function initJournal() {
    const micButton = document.getElementById('micButton');
    const languageSelect = document.getElementById('journalLanguage');
    const transcriptDiv = document.getElementById('transcript');
    
    const sampleTranscripts = {
        english: 'Today was a good day. I felt calm and focused. I completed my tasks and took time for self-care.',
        hindi: 'आज एक अच्छा दिन था। मैं शांत और केंद्रित महसूस किया। मैंने अपने कार्यों को पूरा किया।',
        spanish: 'Hoy fue un buen día. Me sentí tranquilo y enfocado. Completé mis tareas y dediqué tiempo al cuidado personal.',
        french: 'Aujourd\'hui était une bonne journée. Je me sentais calme et concentré. J\'ai terminé mes tâches.'
    };
    
    let isRecording = false;
    
    micButton.addEventListener('click', () => {
        isRecording = !isRecording;
        
        if (isRecording) {
            micButton.classList.add('recording');
            micButton.textContent = '🎤';
            transcriptDiv.textContent = 'Recording...';
            
            setTimeout(() => {
                isRecording = false;
                micButton.classList.remove('recording');
                micButton.textContent = '🎙️';
                const lang = languageSelect.value;
                transcriptDiv.textContent = sampleTranscripts[lang];
                gamification.addPoints(5, 'journals');
                showNotification('Journal entry saved! +5 points');
            }, 3000);
        } else {
            micButton.classList.remove('recording');
            micButton.textContent = '🎙️';
        }
    });
}

function initExercises() {
    const breatheBtn = document.getElementById('breatheBtn');
    const breathingCircle = document.getElementById('breathingCircle');
    const affirmationBtn = document.getElementById('affirmationBtn');
    const affirmationCard = document.getElementById('affirmationCard');
    
    const affirmations = [
        'I am calm and centered.',
        'I choose peace over worry.',
        'I am worthy of love and happiness.',
        'Every breath brings me tranquility.',
        'I release what I cannot control.',
        'I am strong and resilient.',
        'Today, I choose joy.',
        'I am exactly where I need to be.'
    ];
    
    let breathing = false;
    
    breatheBtn.addEventListener('click', () => {
        if (breathing) return;
        breathing = true;
        breatheBtn.disabled = true;
        
        let cycles = 0;
        const maxCycles = 3;
        
        function breatheCycle() {
            breathingCircle.textContent = 'Breathe In...';
            breathingCircle.className = 'breathing-circle breathe-in';
            
            setTimeout(() => {
                breathingCircle.textContent = 'Hold...';
                breathingCircle.className = 'breathing-circle';
                
                setTimeout(() => {
                    breathingCircle.textContent = 'Breathe Out...';
                    breathingCircle.className = 'breathing-circle breathe-out';
                    
                    setTimeout(() => {
                        cycles++;
                        if (cycles < maxCycles) {
                            breatheCycle();
                        } else {
                            breathingCircle.textContent = 'Complete! 🌟';
                            breathingCircle.className = 'breathing-circle';
                            breathing = false;
                            breatheBtn.disabled = false;
                            gamification.addPoints(10, 'exercises');
                            showNotification('Breathing exercise completed! +10 points');
                        }
                    }, 2000);
                }, 2000);
            }, 4000);
        }
        
        breatheCycle();
    });
    
    affirmationBtn.addEventListener('click', () => {
        const randomAffirmation = affirmations[Math.floor(Math.random() * affirmations.length)];
        affirmationCard.textContent = randomAffirmation;
        affirmationCard.style.animation = 'none';
        setTimeout(() => {
            affirmationCard.style.animation = 'fadeIn 1s ease';
        }, 10);
    });
}

function initRewards() {
    const stats = gamification.getStats();
    
    document.getElementById('pointsDisplay').textContent = stats.points;
    document.getElementById('levelDisplay').textContent = stats.level;
    document.getElementById('streakDisplay').textContent = stats.streak;
    
    const progressPercent = ((stats.points % 100) / 100) * 100;
    const progressFill = document.getElementById('progressFill');
    progressFill.style.width = progressPercent + '%';
    progressFill.textContent = `${Math.floor(progressPercent)}%`;
    
    const growthEmoji = document.getElementById('growthEmoji');
    if (stats.level < 3) {
        growthEmoji.textContent = '🌱';
    } else if (stats.level < 6) {
        growthEmoji.textContent = '🌸';
    } else {
        growthEmoji.textContent = '🌳';
    }
    
    const badgesContainer = document.getElementById('badgesContainer');
    const allBadges = [
        { id: 'first_mood', name: 'Mood Tracker', emoji: '😊' },
        { id: 'mood_master', name: 'Mood Master', emoji: '🌟' },
        { id: 'habit_starter', name: 'Habit Starter', emoji: '✓' },
        { id: 'consistent', name: 'Consistent', emoji: '🔥' },
        { id: 'calm_master', name: 'Calm Master', emoji: '🧘' },
        { id: 'journal_pro', name: 'Journal Pro', emoji: '📝' },
        { id: 'task_warrior', name: 'Task Warrior', emoji: '⚔️' },
        { id: 'week_streak', name: '7-Day Streak', emoji: '🌈' },
        { id: 'month_streak', name: '30-Day Streak', emoji: '💎' }
    ];
    
    badgesContainer.innerHTML = '';
    allBadges.forEach(badge => {
        const badgeEl = document.createElement('div');
        const unlocked = stats.badges.find(b => b.id === badge.id);
        badgeEl.className = `badge ${unlocked ? 'unlocked' : ''}`;
        badgeEl.innerHTML = `
            <div class="badge-icon">${badge.emoji}</div>
            <div>${badge.name}</div>
            ${unlocked ? '' : '<div style="font-size: 0.8rem; opacity: 0.6;">Locked</div>'}
        `;
        badgesContainer.appendChild(badgeEl);
    });
    
    const activitiesContainer = document.getElementById('activitiesContainer');
    activitiesContainer.innerHTML = `
        <div class="card">
            <h3>Activity Stats</h3>
            <p>Moods Logged: ${stats.activities.moods || 0}</p>
            <p>Habits Completed: ${stats.activities.habits || 0}</p>
            <p>Tasks Done: ${stats.activities.todos || 0}</p>
            <p>Journal Entries: ${stats.activities.journals || 0}</p>
            <p>Exercises: ${stats.activities.exercises || 0}</p>
        </div>
    `;
}

function initContact() {
    const contactForm = document.getElementById('contactForm');
    
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const message = document.getElementById('message').value.trim();
        
        if (!name || !email || !message) {
            alert('Please fill in all fields.');
            return;
        }
        
        if (!email.includes('@')) {
            alert('Please enter a valid email address.');
            return;
        }
        
        alert('Message sent! Thank you for contacting Echo. We\'ll get back to you soon.');
        contactForm.reset();
    });
}
