# Echo - Wellness Made Simple

## Overview

Echo is a multilingual wellness and mental health companion web application designed to make self-care accessible to everyone, regardless of their native language. The application provides a comprehensive suite of wellness tools including mood tracking, habit building, task management, community chat rooms, AI-powered conversations, voice journaling, mental exercises, and a gamified reward system to encourage consistent engagement with mental health practices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**
- Pure HTML5, CSS3, and vanilla JavaScript (no frameworks)
- Client-side only architecture with no backend services
- Modular multi-page application (MPA) structure

**Design Decisions**
- **No Framework Approach**: Chosen for simplicity, faster load times, and minimal dependencies. This makes the application highly portable and easy to understand.
- **Animated Backgrounds**: Uses CSS keyframe animations with gradient shifts and liquid blob effects to create an engaging, modern aesthetic
- **Responsive Design**: Mobile-first approach with flexible layouts that adapt to different screen sizes
- **Component Reusability**: Consistent navigation bar and footer across all pages maintain user experience continuity

**Page Structure**
The application consists of 11 interconnected pages:
- `index.html` - Landing page with hero section
- `mood.html` - Mood tracking with visual chart
- `habit.html` - Daily habit tracking system
- `todo.html` - Task management interface
- `chai.html` - Multilingual chat rooms
- `ai.html` - AI chatbot with customizable tone
- `journal.html` - Voice journaling feature
- `exercise.html` - Breathing exercises and affirmations
- `rewards.html` - Gamification and progress tracking
- `about.html` - Mission and feature explanation
- `contact.html` - Contact form

### Data Storage Solutions

**LocalStorage-Based Persistence**
- **Problem**: Need for data persistence without backend infrastructure
- **Solution**: Browser localStorage API for client-side data storage
- **Rationale**: Enables persistent user data across sessions while maintaining the frontend-only architecture

**Data Categories Stored**
- Gamification data: points, level, badges, streaks
- Activity tracking: mood logs, habit completions, todos, journal entries
- User preferences: language settings, chatbot tone
- Temporal data: last activity date for streak calculation

**Pros**: 
- No server infrastructure required
- Instant data access
- Works offline
- Simple implementation

**Cons**: 
- Data limited to single browser/device
- Storage capacity limits (~5-10MB)
- No cross-device synchronization
- Data lost if cache cleared

### Gamification System

**Points and Leveling Mechanism**
- Centralized `EchoGamification` class manages all reward logic
- Activity-based point system incentivizes engagement
- Level progression calculated as: `level = floor(points / 100) + 1`
- Streak tracking encourages daily usage

**Activity Tracking**
Monitors user engagement across five categories:
- Mood tracking entries
- Habit completions
- Todo task completion
- Journal entries
- Exercise completions

### Multilingual Support

**Language Selection Architecture**
- Dropdown selectors on relevant pages (Chai Rooms, Voice Journal)
- Supported languages: English, Hindi, Spanish, French
- Language selection stored in localStorage for persistence
- Placeholder implementation (ready for translation integration)

**Design Decision**: Language switching is page-specific rather than global, allowing users to mix languages for different activities (e.g., journal in native language, chat in English)

### Interactive Features

**Canvas-Based Visualizations**
- Mood tracking uses HTML5 Canvas for chart rendering
- Custom chart implementation provides flexibility and reduces dependencies
- Alternative to heavy charting libraries

**Animation System**
- CSS keyframe animations for backgrounds (`gradientShift`, liquid blob effects)
- JavaScript-controlled animations for interactive elements (breathing circle, chat bubbles)
- Smooth transitions enhance user experience

**Simulated Real-Time Features**
- Chat interfaces use setTimeout/setInterval for message simulation
- Breathing exercises use timed animations
- Voice recording simulates speech-to-text with placeholder responses

## External Dependencies

### Browser APIs

**Web Storage API (localStorage)**
- Purpose: Client-side data persistence
- Usage: Storing user progress, preferences, and activity data
- Fallback: None currently implemented (assumption: modern browser environment)

**HTML5 Canvas API**
- Purpose: Data visualization (mood charts, progress indicators)
- Usage: Custom chart rendering without external libraries
- Browser Support: Universal in modern browsers

**Potential Future APIs** (referenced but not implemented)
- **Web Speech API**: For voice journaling feature (currently placeholder)
- **Geolocation API**: Could enhance location-based wellness features

### Third-Party Services (Placeholder Implementation)

**AI Chatbot Service**
- Current: Placeholder responses with tone-based variation
- Integration Point: `ai.html` chat interface
- Expected Service: OpenAI API, Anthropic Claude, or similar conversational AI
- Required Implementation: API key management, request/response handling, error management

**Speech-to-Text Service**
- Current: Simulated transcription in voice journal
- Integration Point: `journal.html` microphone button
- Expected Service: Google Cloud Speech-to-Text, Azure Speech Services, or Web Speech API
- Language Support: Multi-language transcription matching UI language selector

**Translation Service**
- Current: Language selector without actual translation
- Integration Point: All content pages, chat rooms
- Expected Service: Google Translate API, DeepL API
- Implementation Needs: Dynamic content translation, cached translations

**Community Chat Backend**
- Current: Simulated chat with placeholder messages
- Integration Point: `chai.html` Chai Rooms
- Expected Service: WebSocket server (Socket.io, Pusher) or Firebase Realtime Database
- Features Needed: Real-time messaging, language-specific rooms, user authentication

### Asset Dependencies

**No External Libraries**
- Deliberate choice to avoid jQuery, React, Vue, or other frameworks
- Custom implementations for all interactive features
- Trade-off: More code to maintain, but complete control and minimal payload

**Font Dependencies**
- System fonts only ('Segoe UI', Tahoma, Geneva, Verdana, sans-serif)
- No web font loading improves performance
- Ensures consistent cross-platform rendering

### Future Integration Considerations

**Database Migration Path**
- Current localStorage approach should migrate to proper database when backend is added
- Recommended: PostgreSQL with Drizzle ORM for type-safe database operations
- Schema Design Needs: Users, moods, habits, todos, journals, chat_messages, rewards tables

**Authentication System**
- Currently no user authentication
- Future Need: User accounts for cross-device sync
- Recommended: OAuth 2.0 providers (Google, Facebook) + JWT tokens

**Analytics Integration**
- Opportunity: User behavior tracking for wellness insights
- Privacy Consideration: Mental health data requires careful handling
- Recommendation: Privacy-first analytics or self-hosted solution